# PixelFix — Android Photo Editor

A small, native Android photo editor starter built with Kotlin + Jetpack Compose.

## Included
- Gallery photo import
- EXIF orientation correction
- Brightness, contrast, saturation controls
- Presets: Original, Warm, Cool, Mono
- Center-square crop
- 90° rotation
- Reset edits
- Save JPEGs to `Pictures/PixelFix`
- Share edited images through the Android share sheet
- Dark, mobile-first Compose UI

## Open in Android Studio
1. Open the `PixelFix` folder.
2. Let Gradle sync.
3. Use an Android emulator or physical device running Android 8.0 (API 26) or later.
4. Run the `app` configuration.

## Notes
This starter keeps editing local to the device. It does not upload photos to a server.

The environment used to generate this project did not have the Android SDK/Gradle toolchain installed, so I could not produce a verified APK in this workspace. Android Studio will resolve the declared dependencies and build it there.
