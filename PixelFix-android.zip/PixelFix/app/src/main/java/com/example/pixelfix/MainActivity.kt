package com.example.pixelfix

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.PhotoFilter
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Saturation
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private enum class Tool(val title: String) {
    Adjust("Adjust"),
    Filters("Filters")
}

private enum class FilterPreset(val title: String, val brightness: Float, val contrast: Float, val saturation: Float) {
    Original("Original", 0f, 1f, 1f),
    Warm("Warm", 0.05f, 1.05f, 1.18f),
    Cool("Cool", 0.02f, 1.08f, 0.9f),
    Mono("Mono", 0.02f, 1.15f, 0f)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PixelFixTheme {
                PhotoEditorApp()
            }
        }
    }
}

@Composable
private fun PixelFixTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFFB692FF),
            secondary = androidx.compose.ui.graphics.Color(0xFFA9D7FF),
            background = androidx.compose.ui.graphics.Color(0xFF101014),
            surface = androidx.compose.ui.graphics.Color(0xFF17171C),
            surfaceVariant = androidx.compose.ui.graphics.Color(0xFF24242B),
            onBackground = androidx.compose.ui.graphics.Color(0xFFF7F7FA),
            onSurface = androidx.compose.ui.graphics.Color(0xFFF7F7FA)
        ),
        content = content
    )
}

@Composable
private fun PhotoEditorApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var baseBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var selectedTool by remember { mutableStateOf(Tool.Adjust) }
    var selectedPreset by remember { mutableStateOf(FilterPreset.Original) }
    var rotationQuarterTurns by remember { mutableIntStateOf(0) }
    var isProcessing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Choose a photo to start") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            isProcessing = true
            status = "Loading photo…"
            val loaded = withContext(Dispatchers.IO) { loadBitmap(context, uri) }
            original = loaded
            baseBitmap = loaded
            rotationQuarterTurns = 0
            brightness = 0f
            contrast = 1f
            saturation = 1f
            selectedPreset = FilterPreset.Original
            preview = loaded
            status = if (loaded == null) "Couldn’t open that photo" else "Ready to edit"
            isProcessing = false
        }
    }

    LaunchedEffect(baseBitmap, brightness, contrast, saturation) {
        val source = baseBitmap ?: return@LaunchedEffect
        isProcessing = true
        preview = withContext(Dispatchers.Default) {
            applyAdjustments(source, brightness, contrast, saturation)
        }
        isProcessing = false
    }

    val reset = {
        val src = original
        if (src != null) {
            baseBitmap = src
            brightness = 0f
            contrast = 1f
            saturation = 1f
            selectedPreset = FilterPreset.Original
            rotationQuarterTurns = 0
            status = "Edits reset"
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(
                onOpen = { picker.launch("image/*") },
                onReset = reset,
                enabled = original != null
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(androidx.compose.ui.graphics.Color(0xFF0B0B0E)),
                contentAlignment = Alignment.Center
            ) {
                val image = preview
                if (image == null) {
                    EmptyState(onOpen = { picker.launch("image/*") })
                } else {
                    Image(
                        bitmap = image.asImageBitmap(),
                        contentDescription = "Edited photo",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        contentScale = ContentScale.Fit
                    )
                    if (isProcessing) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Rendering…", color = androidx.compose.ui.graphics.Color.White)
                        }
                    }
                }
            }

            Text(
                text = status,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                color = androidx.compose.ui.graphics.Color(0xFFA8A8B2),
                style = MaterialTheme.typography.labelMedium
            )

            ToolTabs(selectedTool) { selectedTool = it }

            when (selectedTool) {
                Tool.Adjust -> {
                    AdjustPanel(
                        brightness = brightness,
                        contrast = contrast,
                        saturation = saturation,
                        onBrightness = { brightness = it },
                        onContrast = { contrast = it },
                        onSaturation = { saturation = it }
                    )
                }
                Tool.Filters -> {
                    FiltersPanel(selectedPreset) { preset ->
                        selectedPreset = preset
                        brightness = preset.brightness
                        contrast = preset.contrast
                        saturation = preset.saturation
                        status = "Applied ${preset.title}"
                    }
                }
            }

            BottomToolbar(
                enabled = preview != null,
                onCrop = {
                    val current = preview ?: return@BottomToolbar
                    baseBitmap = cropCenterSquare(current)
                    brightness = 0f
                    contrast = 1f
                    saturation = 1f
                    selectedPreset = FilterPreset.Original
                    status = "Center-cropped to square"
                },
                onRotate = {
                    val current = baseBitmap ?: return@BottomToolbar
                    baseBitmap = rotateBitmap(current, 90f)
                    rotationQuarterTurns = (rotationQuarterTurns + 1) % 4
                    status = "Rotated ${rotationQuarterTurns * 90}°"
                },
                onSave = {
                    val image = preview ?: return@BottomToolbar
                    scope.launch {
                        status = "Saving…"
                        val uri = withContext(Dispatchers.IO) { saveToGallery(context, image) }
                        status = if (uri != null) "Saved to Photos / Gallery" else "Couldn’t save photo"
                    }
                },
                onShare = {
                    val image = preview ?: return@BottomToolbar
                    scope.launch {
                        val uri = withContext(Dispatchers.IO) { saveToCache(context, image) }
                        if (uri != null) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "image/jpeg"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            ContextCompat.startActivity(context, Intent.createChooser(send, "Share photo"), null)
                            status = "Ready to share"
                        } else {
                            status = "Couldn’t prepare photo for sharing"
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun TopBar(onOpen: () -> Unit, onReset: () -> Unit, enabled: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.AutoFixHigh, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("PixelFix", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Pocket photo editor", color = androidx.compose.ui.graphics.Color(0xFF9A9AA5), style = MaterialTheme.typography.labelSmall)
            }
        }
        Row {
            TextButton(onClick = onOpen) {
                Icon(Icons.Filled.FileUpload, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Open")
            }
            IconButton(onClick = onReset, enabled = enabled) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reset")
            }
        }
    }
}

@Composable
private fun EmptyState(onOpen: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PhotoFilter, contentDescription = null, modifier = Modifier.size(38.dp), tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(16.dp))
        Text("Edit a photo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("Import from your gallery, tune it, then save or share.", color = androidx.compose.ui.graphics.Color(0xFF9A9AA5))
        Spacer(Modifier.height(18.dp))
        Button(onClick = onOpen) {
            Icon(Icons.Filled.FileUpload, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Choose photo")
        }
    }
}

@Composable
private fun ToolTabs(selected: Tool, onSelect: (Tool) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ToolButton("Adjust", Icons.Filled.Tune, selected == Tool.Adjust) { onSelect(Tool.Adjust) }
        ToolButton("Filters", Icons.Filled.PhotoFilter, selected == Tool.Filters) { onSelect(Tool.Filters) }
    }
}

@Composable
private fun ToolButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.width(7.dp))
            Text(label, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
        }
    }
}

@Composable
private fun AdjustPanel(
    brightness: Float,
    contrast: Float,
    saturation: Float,
    onBrightness: (Float) -> Unit,
    onContrast: (Float) -> Unit,
    onSaturation: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
        EditorSlider("Brightness", Icons.Filled.Brightness6, brightness, -1f..1f, onBrightness) { "${(it * 100).roundToInt()}%" }
        EditorSlider("Contrast", Icons.Filled.Contrast, contrast, 0.5f..1.7f, onContrast) { "${(it * 100).roundToInt()}%" }
        EditorSlider("Saturation", Icons.Filled.Saturation, saturation, 0f..2f, onSaturation) { "${(it * 100).roundToInt()}%" }
    }
}

@Composable
private fun EditorSlider(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValue: (Float) -> Unit,
    format: (Float) -> String
) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(label, style = MaterialTheme.typography.labelLarge)
                Text(format(value), color = androidx.compose.ui.graphics.Color(0xFFAAAAB5), style = MaterialTheme.typography.labelMedium)
            }
            Slider(value = value, onValueChange = onValue, valueRange = range)
        }
    }
}

@Composable
private fun FiltersPanel(selected: FilterPreset, onSelect: (FilterPreset) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FilterPreset.entries.forEach { preset ->
            Card(
                modifier = Modifier
                    .width(92.dp)
                    .height(62.dp)
                    .clickable { onSelect(preset) }
                    .border(
                        width = 1.dp,
                        color = if (selected == preset) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent,
                        shape = RoundedCornerShape(14.dp)
                    ),
                shape = RoundedCornerShape(14.dp),
                colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Text(preset.title, fontWeight = if (selected == preset) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun BottomToolbar(
    enabled: Boolean,
    onCrop: () -> Unit,
    onRotate: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SmallAction("Crop", Icons.Filled.Crop, enabled, onCrop)
        SmallAction("Rotate", Icons.Filled.RotateRight, enabled, onRotate)
        Spacer(Modifier.weight(1f))
        Button(onClick = onShare, enabled = enabled, colors = ButtonDefaults.outlinedButtonColors()) {
            Icon(Icons.Filled.IosShare, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Share")
        }
        Button(onClick = onSave, enabled = enabled) {
            Icon(Icons.Filled.SaveAlt, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Save")
        }
    }
}

@Composable
private fun SmallAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(5.dp))
        Text(label)
    }
}

private fun loadBitmap(context: Context, uri: Uri): Bitmap? {
    return try {
        val resolver = context.contentResolver
        val raw = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
        val orientation = resolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
            ?: ExifInterface.ORIENTATION_NORMAL
        applyExifOrientation(raw, orientation)
    } catch (_: Throwable) {
        null
    }
}

private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
        ExifInterface.ORIENTATION_TRANSPOSE -> {
            matrix.setRotate(90f)
            matrix.postScale(-1f, 1f)
        }
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
        ExifInterface.ORIENTATION_TRANSVERSE -> {
            matrix.setRotate(-90f)
            matrix.postScale(-1f, 1f)
        }
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
        else -> return bitmap
    }
    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
}

private fun rotateBitmap(bitmap: Bitmap, degrees: Float): Bitmap {
    val matrix = Matrix().apply { setRotate(degrees) }
    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
}

private fun cropCenterSquare(bitmap: Bitmap): Bitmap {
    val size = minOf(bitmap.width, bitmap.height)
    val left = (bitmap.width - size) / 2
    val top = (bitmap.height - size) / 2
    return Bitmap.createBitmap(bitmap, left, top, size, size)
}

private fun applyAdjustments(source: Bitmap, brightness: Float, contrast: Float, saturation: Float): Bitmap {
    val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(source.width * source.height)
    source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)

    val b = brightness * 255f
    val c = contrast.coerceIn(0f, 3f)
    val s = saturation.coerceIn(0f, 3f)
    val lumR = 0.213f
    val lumG = 0.715f
    val lumB = 0.072f

    for (i in pixels.indices) {
        val p = pixels[i]
        var r = ((p shr 16) and 0xFF).toFloat()
        var g = ((p shr 8) and 0xFF).toFloat()
        var bl = (p and 0xFF).toFloat()

        r = (r - 128f) * c + 128f + b
        g = (g - 128f) * c + 128f + b
        bl = (bl - 128f) * c + 128f + b

        val gray = r * lumR + g * lumG + bl * lumB
        r = gray + (r - gray) * s
        g = gray + (g - gray) * s
        bl = gray + (bl - gray) * s

        pixels[i] = Color.argb(Color.alpha(p), clamp8(r), clamp8(g), clamp8(bl))
    }
    out.setPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
    return out
}

private fun clamp8(value: Float): Int = value.roundToInt().coerceIn(0, 255)

private fun saveToGallery(context: Context, bitmap: Bitmap): Uri? {
    val resolver = context.contentResolver
    val fileName = "PixelFix_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PixelFix")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
    }

    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    try {
        resolver.openOutputStream(uri)?.use { output ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 94, output)
        } ?: throw IllegalStateException("No output stream")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val complete = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, complete, null, null)
        }
        return uri
    } catch (_: Throwable) {
        resolver.delete(uri, null, null)
        return null
    }
}

private fun saveToCache(context: Context, bitmap: Bitmap): Uri? {
    return try {
        val dir = File(context.cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "pixelfix_share.jpg")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 94, it) }
        androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    } catch (_: Throwable) {
        null
    }
}
